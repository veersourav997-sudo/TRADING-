import type { NextApiRequest, NextApiResponse } from "next";
import fetch from "node-fetch";

// interval: 1d, 1wk, 1mo, 5m, etc. Yahoo format
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const symbol = req.query.symbol as string;
  const interval = req.query.interval as string || "1d";
  if (!symbol) {
    res.status(400).json({ error: "Symbol is required" });
    return;
  }
  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=${interval}&range=3mo`;
    const response = await fetch(url);
    const data = await response.json();
    const result = data.chart.result?.[0];
    if (!result) throw new Error("No data");
    const timestamps = result.timestamp;
    const ohlcv = result.indicators.quote[0];
    const candles = timestamps.map((t, i) => ({
      time: t,
      open: ohlcv.open[i],
      high: ohlcv.high[i],
      low: ohlcv.low[i],
      close: ohlcv.close[i],
      volume: ohlcv.volume[i],
    }));
    res.status(200).json({ candles });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch OHLCV" });
  }
}