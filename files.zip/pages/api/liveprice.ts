import type { NextApiRequest, NextApiResponse } from "next";
import fetch from "node-fetch";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const symbol = req.query.symbol as string;
  if (!symbol) {
    res.status(400).json({ error: "Symbol is required" });
    return;
  }
  try {
    const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbol}`;
    const response = await fetch(url);
    const data = await response.json();
    const price = data.quoteResponse.result[0]?.regularMarketPrice;
    res.status(200).json({ price });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch price" });
  }
}