import type { NextApiRequest, NextApiResponse } from "next";
import fetch from "node-fetch";

// Yahoo Finance autocomplete API (unofficial)
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const q = req.query.q as string;
  if (!q) {
    res.status(400).json({ symbols: [] });
    return;
  }
  try {
    const url = `https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&lang=en-IN`;
    const response = await fetch(url);
    const data = await response.json();
    const symbols = (data.quotes || [])
      .filter(s => s.exchange === "NSI" || s.exchange === "BSE")
      .map(s => ({
        symbol: s.symbol,
        name: s.shortname || s.longname || s.symbol,
        exchange: s.exchange,
      }));
    res.status(200).json({ symbols });
  } catch (err) {
    res.status(500).json({ symbols: [] });
  }
}