import { useEffect, useState } from "react";
import ChartHeader from "../components/ChartHeader";
import TradingChart from "../components/TradingChart";

export default function Home() {
  const [symbol, setSymbol] = useState("RELIANCE.NS");
  const [interval, setInterval] = useState("1d");
  const [indicators, setIndicators] = useState([]);
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    if (!symbol || !interval) return;
    fetch(`/api/ohlcv?symbol=${encodeURIComponent(symbol)}&interval=${interval}`)
      .then(res => res.json())
      .then(data => setChartData(data.candles || []));
  }, [symbol, interval]);

  const addIndicator = (ind) => setIndicators(i => [...i, ind]);

  // Map UI interval to Yahoo API interval
  const getYahooInterval = (uiInt) => {
    if (uiInt.includes("minute")) return uiInt.split(" ")[0] + "m";
    if (uiInt.includes("hour")) return uiInt.split(" ")[0] + "h";
    if (uiInt.includes("day")) return "1d";
    if (uiInt.includes("week")) return "1wk";
    if (uiInt.includes("month")) return "1mo";
    return "1d";
  };

  useEffect(() => {
    setInterval(getYahooInterval(interval));
  }, [interval]);

  return (
    <div>
      <ChartHeader
        symbol={symbol}
        setSymbol={setSymbol}
        interval={interval}
        setInterval={setInterval}
        indicators={indicators}
        addIndicator={addIndicator}
      />
      <TradingChart symbol={symbol} interval={interval} data={chartData} indicators={indicators} />
    </div>
  );
}