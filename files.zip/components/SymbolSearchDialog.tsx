import { useState } from "react";

export default function SymbolSearchDialog({ open, onClose, onSelect }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);

  // Dynamic Yahoo symbol search (NSE/BSE)
  const handleSearch = async (q) => {
    setQuery(q);
    if (!q) {
      setResults([]);
      return;
    }
    // Use Yahoo Finance API for autocomplete (or your backend)
    const res = await fetch(`/api/symbolsearch?q=${encodeURIComponent(q)}`);
    const data = await res.json();
    setResults(data.symbols || []);
  };

  return open ? (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg w-[400px] max-h-[80vh] flex flex-col">
        <div className="flex items-center px-4 py-2 border-b">
          <span className="font-bold text-lg flex-1">Symbol Search</span>
          <button onClick={onClose} className="text-gray-500 hover:text-black p-2">×</button>
        </div>
        <div className="px-4 py-2">
          <input
            className="border p-2 rounded w-full"
            placeholder="Search symbol (NSE/BSE)..."
            value={query}
            autoFocus
            onChange={e => handleSearch(e.target.value)}
          />
        </div>
        <div className="flex-1 overflow-auto px-4 pb-4">
          {results.length === 0 ? (
            <div className="text-gray-500 p-8 text-center">Type to search for NSE/BSE stocks.</div>
          ) : (
            <ul>
              {results.map(sym => (
                <li key={sym.symbol}
                  className="flex items-center py-2 px-2 cursor-pointer hover:bg-blue-50 rounded"
                  onClick={() => { onSelect(sym.symbol); onClose(); }}>
                  <span className="font-bold text-blue-700">{sym.symbol}</span>
                  <span className="ml-2 text-gray-700">{sym.name}</span>
                  <span className="ml-auto text-xs text-gray-400">{sym.exchange}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="px-4 py-2 text-xs text-gray-400 border-t">
          Yahoo format: RELIANCE.NS, TCS.NS, SBIN.NS, etc.
        </div>
      </div>
    </div>
  ) : null;
}