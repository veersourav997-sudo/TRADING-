import { useEffect, useRef } from "react";
import { createChart } from "lightweight-charts";

// Drawing tools and indicators are extensible via plugins or custom overlays
export default function TradingChart({ symbol, interval, data, indicators }) {
  const chartRef = useRef();

  useEffect(() => {
    if (!data?.length) return;
    chartRef.current.innerHTML = "";
    const chart = createChart(chartRef.current, { width: 900, height: 480 });
    const candleSeries = chart.addCandlestickSeries();

    candleSeries.setData(data);

    // Example: Add indicators overlays (stub)
    // You can fetch and display SMA/EMA overlays here

    // Drawing tools: see lightweight-charts-drawing-tools plugin (or custom overlays)

    return () => chart.remove();
  }, [symbol, interval, data, indicators]);

  return (
    <div ref={chartRef} style={{ width: "100%", height: 480, background: "#fff" }} />
  );
}