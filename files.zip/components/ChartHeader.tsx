import SymbolSearchDialog from "./SymbolSearchDialog";
import ChartIntervalSelector from "./ChartIntervalSelector";
import LivePriceTicker from "./LivePriceTicker";
import IndicatorPanel from "./IndicatorPanel";
import { useState } from "react";

export default function ChartHeader({ symbol, setSymbol, interval, setInterval, indicators, addIndicator }) {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="flex items-center gap-4 p-3 bg-gray-50 border-b">
      <button
        className="px-3 py-1 bg-blue-600 text-white rounded"
        onClick={() => setSearchOpen(true)}
      >Symbol Search</button>
      <SymbolSearchDialog
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelect={setSymbol}
      />
      <LivePriceTicker symbol={symbol} />
      <ChartIntervalSelector selected={interval} onSelect={setInterval} />
      <IndicatorPanel onAdd={addIndicator} />
      <div className="ml-auto flex gap-2">
        {indicators.map(ind => (
          <span key={ind} className="px-2 py-1 bg-blue-100 rounded text-xs font-bold text-blue-700">{ind}</span>
        ))}
      </div>
    </div>
  );
}