import { useState } from "react";

const INDICATORS = [
  "SMA",
  "EMA",
  "RSI",
  "MACD",
  "Bollinger Bands",
  "Volume",
];

export default function IndicatorPanel({ onAdd }) {
  const [selected, setSelected] = useState("");
  return (
    <div className="flex gap-2 items-center">
      <select
        className="border p-2 rounded"
        value={selected}
        onChange={e => setSelected(e.target.value)}
      >
        <option value="">Add Indicator…</option>
        {INDICATORS.map(ind => (
          <option key={ind} value={ind}>{ind}</option>
        ))}
      </select>
      <button
        className="px-2 py-1 bg-blue-600 text-white rounded"
        disabled={!selected}
        onClick={() => { onAdd(selected); setSelected(""); }}
      >Add</button>
    </div>
  );
}