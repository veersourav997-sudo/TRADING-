import { useState } from "react";

const INTERVAL_GROUPS = [
  { label: "Ticks", intervals: ["1 tick", "10 ticks", "100 ticks", "1000 ticks"] },
  { label: "Seconds", intervals: ["1 second", "5 seconds", "10 seconds", "15 seconds", "30 seconds", "45 seconds"] },
  { label: "Minutes", intervals: ["1 minute", "2 minutes", "3 minutes", "5 minutes", "10 minutes", "15 minutes", "30 minutes", "45 minutes"] },
  { label: "Hours", intervals: ["1 hour", "2 hours", "3 hours", "4 hours"] },
  { label: "Days", intervals: ["1 day", "1 week", "1 month", "3 months", "6 months", "12 months"] },
  { label: "Ranges", intervals: ["1 range", "10 ranges", "100 ranges", "1000 ranges"] },
];

export default function ChartIntervalSelector({ selected, onSelect }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative inline-block min-w-[120px]">
      <button
        className="px-3 py-2 border bg-white shadow rounded w-full flex items-center justify-between"
        onClick={() => setOpen(!open)}
        title="Change chart interval"
      >
        <span>{selected || "Interval"}</span>
        <span className="ml-2">&#9660;</span>
      </button>
      {open && (
        <div className="absolute left-0 top-full mt-2 w-60 bg-white border rounded shadow-lg z-10 max-h-[600px] overflow-y-auto">
          <div className="px-3 py-2 border-b font-bold text-blue-700 cursor-pointer"
            onClick={() => { onSelect("custom"); setOpen(false); }}
          >
            + Add custom interval…
          </div>
          {INTERVAL_GROUPS.map(({ label, intervals }) => (
            <div key={label} className="py-2">
              <div className="px-3 text-xs font-semibold text-gray-500">{label.toUpperCase()}</div>
              {intervals.map(opt => (
                <div
                  key={opt}
                  className={`px-3 py-1 cursor-pointer hover:bg-blue-50 rounded ${selected === opt ? "bg-blue-100 font-bold" : ""}`}
                  onClick={() => { onSelect(opt); setOpen(false); }}
                >
                  {opt}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}