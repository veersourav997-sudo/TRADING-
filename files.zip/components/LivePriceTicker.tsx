import { useEffect, useState } from "react";

export default function LivePriceTicker({ symbol }) {
  const [price, setPrice] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!symbol) return;
    setLoading(true);
    fetch(`/api/liveprice?symbol=${encodeURIComponent(symbol)}`)
      .then(res => res.json())
      .then(data => {
        setPrice(data.price);
        setLoading(false);
      });
  }, [symbol]);

  return (
    <div>
      <span className="font-bold">{symbol}</span>
      {" : "}
      <span className="text-green-600">
        {loading ? "Loading..." : price !== null ? price : "N/A"}
      </span>
      <span className="text-xs text-gray-400 ml-2">(Yahoo Finance, delayed)</span>
    </div>
  );
}